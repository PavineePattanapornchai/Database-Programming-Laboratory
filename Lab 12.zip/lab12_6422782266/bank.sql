-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 14, 2023 at 01:54 PM
-- Server version: 5.7.24
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bank`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `DepositMoney` (IN `account_id` INT, IN `deposit_amount` FLOAT)   BEGIN
    UPDATE accounts
    SET bal = bal + deposit_amount
    WHERE id = account_id;

    INSERT INTO transactions (type, amount, date, accid)
    VALUES ('D', deposit_amount, NOW(), account_id);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `WithdrawMoney` (IN `account_id` INT, IN `withdraw_amount` FLOAT)   BEGIN
    DECLARE current_balance FLOAT;
    SELECT bal INTO current_balance FROM accounts WHERE id = account_id;
    
    IF current_balance >= withdraw_amount THEN
        UPDATE accounts
        SET bal = bal - withdraw_amount
        WHERE id = account_id;
        
        INSERT INTO transactions (type, amount, date, accid)
        VALUES ('W', withdraw_amount, NOW(), account_id);
    ELSE
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Not enough money';
    END IF;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `ID` int(11) NOT NULL,
  `No.` varbinary(20) DEFAULT NULL,
  `name` varbinary(200) DEFAULT NULL,
  `CreditLimit` double DEFAULT NULL,
  `bal` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`ID`, `No.`, `name`, `CreditLimit`, `bal`) VALUES
(105, 0x4e3031, 0x4a6f686e204d6f72726973, 20000, 13000);

-- --------------------------------------------------------

--
-- Stand-in structure for view `account_view`
-- (See below for the actual view)
--
CREATE TABLE `account_view` (
`Account No.` varbinary(20)
,`Name` varbinary(200)
,`Balance` float
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `protected_account_view`
-- (See below for the actual view)
--
CREATE TABLE `protected_account_view` (
`Account No.` varchar(17)
,`Name` varchar(12)
,`Balance` double(19,2)
);

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `id` int(11) NOT NULL,
  `type` char(1) CHARACTER SET utf8mb4 DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `accid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Triggers `transaction`
--
DELIMITER $$
CREATE TRIGGER `CheckBalanceBeforeInsert` BEFORE INSERT ON `transaction` FOR EACH ROW BEGIN
    DECLARE current_balance FLOAT;
    SELECT bal INTO current_balance FROM accounts WHERE id = NEW.accid;
    
    IF current_balance >= NEW.amount THEN
        UPDATE accounts
        SET bal = bal - NEW.amount
        WHERE id = NEW.accid;
    ELSE
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Not enough money';
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `PreventTransactionEdit` BEFORE UPDATE ON `transaction` FOR EACH ROW BEGIN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Transaction edits are not allowed';
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `Password` varbinary(100) DEFAULT NULL,
  `SecurityLevel` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `UserName`, `Password`, `SecurityLevel`) VALUES
(1, 'admin', 0xfa7b776d448dd9122add62c2c45883a5, 'Admin'),
(2, 'staff', 0x14f6408e8d1b6ccd5794282e0e3579fd, 'Staff'),
(3, 'customer', 0x43c5144eef888ba0bd4aaa8f037dc4bbfc663ec37c90c2b3b07960c4da2cf89a, 'Customer');

-- --------------------------------------------------------

--
-- Structure for view `account_view`
--
DROP TABLE IF EXISTS `account_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `account_view`  AS SELECT `account`.`No.` AS `Account No.`, `account`.`name` AS `Name`, `account`.`bal` AS `Balance` FROM `account``account`  ;

-- --------------------------------------------------------

--
-- Structure for view `protected_account_view`
--
DROP TABLE IF EXISTS `protected_account_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `protected_account_view`  AS SELECT concat(substr(md5(rand()),1,8),'/',substr(md5(rand()),1,8)) AS `Account No.`, concat('?',convert(substr(md5(rand()),1,10) using tis620),'?') AS `Name`, round((rand() * 10000),2) AS `Balance` FROM `account``account`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
