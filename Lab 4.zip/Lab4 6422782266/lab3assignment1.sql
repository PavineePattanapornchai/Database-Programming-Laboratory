-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 12, 2023 at 04:41 AM
-- Server version: 5.7.24
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lab3assignment1`
--

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `StudentID` bigint(20) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Course ID` smallint(6) NOT NULL,
  `Course no.` tinyint(4) NOT NULL,
  `Course name` varchar(50) NOT NULL,
  `Coursecode` varchar(8) NOT NULL,
  `Grade` char(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`StudentID`, `FirstName`, `LastName`, `Course ID`, `Course no.`, `Course name`, `Coursecode`, `Grade`) VALUES
(6022040411, 'Adam', 'Phelps', 4576, 45, 'Programming', 'ITS341', 'A'),
(6022040412, 'Mark', 'Twain', 4576, 45, 'Programming', 'ITS341', 'B'),
(6022040413, 'Shania', 'Judith', 2345, 24, 'Critical Thinking', 'GC124', 'A'),
(6022040414, 'Angelina', 'Rosswell', 1458, 12, 'CAD/CAM', 'ME231', 'B+'),
(6022040415, 'Thomas', 'Hardy', 2345, 24, 'Critical Thinking', 'GC124', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `Registration ID` smallint(6) NOT NULL,
  `StudentID` bigint(20) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Section ID` smallint(6) NOT NULL,
  `Grade` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`Registration ID`, `StudentID`, `FirstName`, `LastName`, `Section ID`, `Grade`) VALUES
(602, 6022040411, 'Adam', 'Phelps', 623, 'A'),
(603, 6022040412, 'Mark', 'Twain', 625, 'B'),
(604, 6022040413, 'Shania', 'Judith', 354, 'A'),
(605, 6022040414, 'Angelina', 'Rosswell', 267, 'C'),
(606, 6022040415, 'Thomas', 'Hardy', 147, 'A');

-- --------------------------------------------------------

--
-- Table structure for table `section`
--

CREATE TABLE `section` (
  `StudentID` bigint(20) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Section ID` smallint(6) NOT NULL,
  `Section no.` tinyint(4) NOT NULL,
  `Grade` char(1) NOT NULL,
  `Semester` tinyint(4) NOT NULL,
  `Year` year(4) NOT NULL,
  `Course ID` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `section`
--

INSERT INTO `section` (`StudentID`, `FirstName`, `LastName`, `Section ID`, `Section no.`, `Grade`, `Semester`, `Year`, `Course ID`) VALUES
(6022040411, 'Adam', 'Phelps', 623, 1, 'A', 1, 2019, 4576),
(6022040412, 'Mark', 'Twain', 625, 3, 'B', 1, 2019, 4576),
(6022040413, 'Shania', 'Judith', 354, 2, 'A', 1, 2019, 2345),
(6022040414, 'Angelina', 'Rosswell', 267, 1, 'C', 2, 2020, 1458),
(6022040415, 'Thomas', 'Hardy', 147, 2, 'A', 2, 2020, 2345);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `StudentID` bigint(15) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Sex` varchar(50) NOT NULL,
  `City` varchar(50) NOT NULL,
  `Curriculum` varchar(50) NOT NULL,
  `Dateofbirth` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`StudentID`, `FirstName`, `LastName`, `Sex`, `City`, `Curriculum`, `Dateofbirth`) VALUES
(6022040411, 'Adam', 'Phelps', 'Male', 'New York', 'ICT', '2000-07-24'),
(6022040412, 'Mark', 'Twain', 'Male', 'Los Angeles', 'ICT', '2002-09-13'),
(6022040413, 'Shania', 'Judith', 'Female', 'New York', 'CIVIL', '2001-05-19'),
(6022040414, 'Angelina', 'Rosswell', 'Female', 'California', 'MECHANICAL', '2002-07-27'),
(6022040415, 'Thomas', 'Hardy', 'Male', 'New York', 'MANAGEMENT', '2006-03-19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD KEY `Course ID` (`Course ID`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`Registration ID`),
  ADD KEY `Student ID` (`StudentID`),
  ADD KEY `Section ID` (`Section ID`);

--
-- Indexes for table `section`
--
ALTER TABLE `section`
  ADD PRIMARY KEY (`StudentID`),
  ADD UNIQUE KEY `Section ID` (`Section ID`),
  ADD KEY `Course ID` (`Course ID`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`StudentID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `registration`
--
ALTER TABLE `registration`
  ADD CONSTRAINT `registration_ibfk_1` FOREIGN KEY (`StudentID`) REFERENCES `student` (`StudentID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `registration_ibfk_2` FOREIGN KEY (`Section ID`) REFERENCES `section` (`Section ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `section`
--
ALTER TABLE `section`
  ADD CONSTRAINT `section_ibfk_1` FOREIGN KEY (`Course ID`) REFERENCES `course` (`Course ID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
