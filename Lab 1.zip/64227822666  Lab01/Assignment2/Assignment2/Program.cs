﻿using System;
class Program
{
    static void Main()
    {
        Console.WriteLine("Enter the number: ");
        int num = Convert.ToInt32(Console.ReadLine());
        int sum = 0;
        /*
        //while Loop
        int i = 1;
        if(num > 0) {
            while (i <= num)
            {
                sum += i;
                i++;
            }
            Console.WriteLine("The sum of nubers from 1 to" + num + "is : " + sum);
        }
        else
        {
            Console.WriteLine("Please enter a positive integer");
        }
        */

        //for loop
        if (num > 0)
        {
            for (int i = 1; i <= num; i++)
            {
                sum += i;
            }
            Console.WriteLine("The sum of nubers from 1 to " + num + " is : " + sum);
        }
        else
        {
            Console.WriteLine("Please enter a positive integer");
        }

    }
}