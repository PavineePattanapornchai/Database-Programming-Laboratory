﻿using System;
public class Program
{
    public static double Avg(double[] arr)
    {
        return arr.Sum() / arr.Length;
    }
    public static void Main()
    {
        Console.WriteLine("Enter the number of student: ");
        int size = Convert.ToInt32(Console.ReadLine());
        double[] scores = new double[size];

        for (int i = 0; i < size; i++)
        {
            Console.WriteLine($"Enter the score for student {i + 1} :");
            scores[i] = Convert.ToDouble(Console.ReadLine());
        }

        Console.WriteLine("The class average is: " + Avg(scores));
    }
}