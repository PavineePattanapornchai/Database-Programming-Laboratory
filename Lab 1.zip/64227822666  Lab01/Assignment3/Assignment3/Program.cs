﻿using System;
class Program
{
    static void Main()
    {
        Console.WriteLine("Enter the number of elements in the array: ");
        int size = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter " + size + " integers elements: ");
        int[] arr = new int[size];

        for (int i = 0; i < size; i++)
        {
            Console.WriteLine("Element " + (i + 1) + " :");
            arr[i] = Convert.ToInt32(Console.ReadLine());
        }

        Console.WriteLine("Sum of elements: " + arr.Sum());
        Console.WriteLine("Maximum element: " + arr.Max());
        Console.WriteLine("Minimum element: " + arr.Min());
        Console.WriteLine("Average of element: " + (Convert.ToDouble(arr.Sum()) / arr.Length));


    }
}