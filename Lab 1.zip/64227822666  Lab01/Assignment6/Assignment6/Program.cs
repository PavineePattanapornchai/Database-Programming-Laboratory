﻿using System;
namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            Student student = new Student();
            bool exit = false;

            Console.WriteLine("===== Student Management System ===== \n" +
                "1. Add a new student \n" + "2. Display all students \n" + "3. Search student by ID \n" + "4. Exit");           

            while (!exit)
            {
                Console.WriteLine("\nEnter your choice: ");
                int choice = Convert.ToInt32(Console.ReadLine());

                if (choice == 1)
                {
                    Console.WriteLine("\nEnter student's name: ");
                    string name = Console.ReadLine();
                    Console.WriteLine("Enter student's age: ");
                    int age = Convert.ToInt32(Console.ReadLine());
                    student.Add(name, age);
                    Console.WriteLine("Student added successfully!");
                }
                if (choice == 2)
                {
                    student.Display();
                }
                if (choice == 3)
                {
                    Console.WriteLine("\nEnter student ID to search: ");
                    int search_id = Convert.ToInt32(Console.ReadLine());
                    student.Search(search_id);

                }
                if (choice == 4)
                {
                    Console.WriteLine("\nExiting the program...");
                    exit = true;
                }
            }


        }
    }
}

public class Student
{
    public List<int> Id = new List<int>();
    public List<string> Names = new List<string>();
    public List<int> Ages = new List<int>();

    public void Add(string name, int age)
    {
        Names.Add(name);
        Ages.Add(age);
        Id.Add(Names.IndexOf(name) + 1);
    }

    public void Display()
    {
        Console.WriteLine("\n----- List of Students -----");
        for (int i = 0; i < Id.Count; i++)
        {
            Console.WriteLine($"ID: {Id[i]}, Name: {Names[i]}, Age: {Ages[i]}");
        }
    }

    public void Search(int ID)
    {
        if (ID <= Id.Count)
        {
            Console.WriteLine("----- Student Found -----");
            Console.WriteLine($"ID: {Id[ID - 1]}, Name: {Names[ID - 1]}, Age: {Ages[ID - 1]}");
        }
        else
        {
            Console.WriteLine($"Student with ID {ID} not found.");
        }
    }
}
