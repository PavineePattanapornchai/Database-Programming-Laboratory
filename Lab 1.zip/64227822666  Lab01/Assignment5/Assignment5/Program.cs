﻿using System;
namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            Item item1 = new Item("Shirt", 25.99);
            Item item2 = new Item("Jeans", 39.99);
            Item item3 = new Item("Shoes", 49.99);

            Cart cart = new Cart();
            cart.addItem(item1);
            cart.addItem(item2);
            cart.addItem(item3);
            cart.display();
        }
    }
}

public class Item
{
    public string Name;
    public double Price;

    public Item(string name, double price)
    {
        Name = name;
        Price = price;
    }
}

public class Cart
{
    public List<double> Prices = new List<double>();
    public List<string> Names = new List<string>();

    public void addItem(Item item)
    {
        Names.Add(item.Name);
        Prices.Add(item.Price);
    }

    public double calculateTotal()
    {
        return Prices.Sum();
    }

    public void display()
    {
        Console.WriteLine("Shopping Cart Contents:");
        for (int i = 0; i < Prices.Count; i++)
        {
            Console.WriteLine($"{Names[i]} - ${Prices[i]}");
        }
        Console.WriteLine("Total Price: $" + calculateTotal());
    }
}