﻿namespace signup
{
    partial class signup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox2 = new GroupBox();
            label11 = new Label();
            label12 = new Label();
            passlog = new TextBox();
            userlog = new TextBox();
            groupBox1 = new GroupBox();
            sxCombo = new ComboBox();
            dateTimePick = new DateTimePicker();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            email = new TextBox();
            occupation = new TextBox();
            lname = new TextBox();
            fname = new TextBox();
            groupBox3 = new GroupBox();
            label7 = new Label();
            label8 = new Label();
            passsignup = new TextBox();
            usersignup = new TextBox();
            label9 = new Label();
            cfpasssignup = new TextBox();
            label10 = new Label();
            submit = new Button();
            groupBox2.SuspendLayout();
            groupBox1.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(label11);
            groupBox2.Controls.Add(label12);
            groupBox2.Controls.Add(passlog);
            groupBox2.Controls.Add(userlog);
            groupBox2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox2.Location = new Point(961, 187);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(846, 269);
            groupBox2.TabIndex = 14;
            groupBox2.TabStop = false;
            groupBox2.Text = "Personal Information";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(102, 187);
            label11.Name = "label11";
            label11.Size = new Size(165, 45);
            label11.TabIndex = 5;
            label11.Text = "Password:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(87, 92);
            label12.Name = "label12";
            label12.Size = new Size(175, 45);
            label12.TabIndex = 4;
            label12.Text = "Username:";
            // 
            // passlog
            // 
            passlog.Location = new Point(323, 187);
            passlog.Name = "passlog";
            passlog.Size = new Size(400, 50);
            passlog.TabIndex = 1;
            // 
            // userlog
            // 
            userlog.Location = new Point(323, 92);
            userlog.Name = "userlog";
            userlog.Size = new Size(400, 50);
            userlog.TabIndex = 0;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(sxCombo);
            groupBox1.Controls.Add(dateTimePick);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(email);
            groupBox1.Controls.Add(occupation);
            groupBox1.Controls.Add(lname);
            groupBox1.Controls.Add(fname);
            groupBox1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox1.Location = new Point(109, 166);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(846, 645);
            groupBox1.TabIndex = 13;
            groupBox1.TabStop = false;
            groupBox1.Text = "Personal Information";
            // 
            // sxCombo
            // 
            sxCombo.FormattingEnabled = true;
            sxCombo.Items.AddRange(new object[] { "Male", "Female", "other" });
            sxCombo.Location = new Point(323, 271);
            sxCombo.Name = "sxCombo";
            sxCombo.Size = new Size(400, 53);
            sxCombo.TabIndex = 11;
            // 
            // dateTimePick
            // 
            dateTimePick.Location = new Point(323, 358);
            dateTimePick.Name = "dateTimePick";
            dateTimePick.Size = new Size(400, 50);
            dateTimePick.TabIndex = 10;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(84, 538);
            label6.Name = "label6";
            label6.Size = new Size(195, 45);
            label6.TabIndex = 9;
            label6.Text = "Occupation:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(173, 450);
            label5.Name = "label5";
            label5.Size = new Size(106, 45);
            label5.TabIndex = 8;
            label5.Text = "Email:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(102, 358);
            label4.Name = "label4";
            label4.Size = new Size(177, 45);
            label4.TabIndex = 7;
            label4.Text = "Birth Date:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(207, 274);
            label3.Name = "label3";
            label3.Size = new Size(78, 45);
            label3.TabIndex = 6;
            label3.Text = "Sex:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(102, 187);
            label2.Name = "label2";
            label2.Size = new Size(183, 45);
            label2.TabIndex = 5;
            label2.Text = "Last Name:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(87, 92);
            label1.Name = "label1";
            label1.Size = new Size(198, 45);
            label1.TabIndex = 4;
            label1.Text = "Frirst Name:";
            // 
            // email
            // 
            email.Location = new Point(323, 450);
            email.Name = "email";
            email.Size = new Size(400, 50);
            email.TabIndex = 3;
            // 
            // occupation
            // 
            occupation.Location = new Point(323, 538);
            occupation.Name = "occupation";
            occupation.Size = new Size(400, 50);
            occupation.TabIndex = 2;
            // 
            // lname
            // 
            lname.Location = new Point(323, 187);
            lname.Name = "lname";
            lname.Size = new Size(400, 50);
            lname.TabIndex = 1;
            // 
            // fname
            // 
            fname.Location = new Point(323, 92);
            fname.Name = "fname";
            fname.Size = new Size(400, 50);
            fname.TabIndex = 0;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(label9);
            groupBox3.Controls.Add(cfpasssignup);
            groupBox3.Controls.Add(label7);
            groupBox3.Controls.Add(label8);
            groupBox3.Controls.Add(passsignup);
            groupBox3.Controls.Add(usersignup);
            groupBox3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox3.Location = new Point(961, 462);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(846, 349);
            groupBox3.TabIndex = 15;
            groupBox3.TabStop = false;
            groupBox3.Text = "Personal Information";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(136, 181);
            label7.Name = "label7";
            label7.Size = new Size(165, 45);
            label7.TabIndex = 5;
            label7.Text = "Password:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(121, 97);
            label8.Name = "label8";
            label8.Size = new Size(175, 45);
            label8.TabIndex = 4;
            label8.Text = "Username:";
            // 
            // passsignup
            // 
            passsignup.Location = new Point(357, 181);
            passsignup.Name = "passsignup";
            passsignup.Size = new Size(400, 50);
            passsignup.TabIndex = 1;
            // 
            // usersignup
            // 
            usersignup.Location = new Point(357, 97);
            usersignup.Name = "usersignup";
            usersignup.Size = new Size(400, 50);
            usersignup.TabIndex = 0;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(44, 264);
            label9.Name = "label9";
            label9.Size = new Size(291, 45);
            label9.TabIndex = 7;
            label9.Text = "Confirm Password:";
            // 
            // cfpasssignup
            // 
            cfpasssignup.Location = new Point(357, 261);
            cfpasssignup.Name = "cfpasssignup";
            cfpasssignup.Size = new Size(400, 50);
            cfpasssignup.TabIndex = 6;
            // 
            // label10
            // 
            label10.BackColor = SystemColors.ActiveCaption;
            label10.Font = new Font("Segoe UI Black", 24F, FontStyle.Bold, GraphicsUnit.Point);
            label10.Location = new Point(57, 34);
            label10.Name = "label10";
            label10.Size = new Size(1793, 102);
            label10.TabIndex = 16;
            label10.Text = "Information Collector";
            // 
            // submit
            // 
            submit.BackColor = SystemColors.ActiveCaption;
            submit.Font = new Font("Segoe UI", 13.875F, FontStyle.Bold, GraphicsUnit.Point);
            submit.Location = new Point(869, 839);
            submit.Name = "submit";
            submit.Size = new Size(183, 60);
            submit.TabIndex = 17;
            submit.Text = "Submit";
            submit.UseVisualStyleBackColor = false;
            // 
            // signup
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1907, 968);
            Controls.Add(submit);
            Controls.Add(label10);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "signup";
            Text = "signup";
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox2;
        private Label label11;
        private Label label12;
        private TextBox passlog;
        private TextBox userlog;
        private GroupBox groupBox1;
        private ComboBox sxCombo;
        private DateTimePicker dateTimePick;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox email;
        private TextBox occupation;
        private TextBox lname;
        private TextBox fname;
        private GroupBox groupBox3;
        private Label label9;
        private TextBox cfpasssignup;
        private Label label7;
        private Label label8;
        private TextBox passsignup;
        private TextBox usersignup;
        private Label label10;
        private Button submit;
    }
}