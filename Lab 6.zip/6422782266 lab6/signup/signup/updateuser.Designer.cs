﻿namespace signup
{
    partial class updateuser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            submit = new Button();
            groupBox1 = new GroupBox();
            sxCombo = new ComboBox();
            dateTimePick = new DateTimePicker();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            email = new TextBox();
            occupation = new TextBox();
            lname = new TextBox();
            fname = new TextBox();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // submit
            // 
            submit.BackColor = SystemColors.ActiveCaption;
            submit.Font = new Font("Segoe UI", 13.875F, FontStyle.Bold, GraphicsUnit.Point);
            submit.Location = new Point(883, 714);
            submit.Name = "submit";
            submit.Size = new Size(183, 60);
            submit.TabIndex = 19;
            submit.Text = "Submit";
            submit.UseVisualStyleBackColor = false;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(sxCombo);
            groupBox1.Controls.Add(dateTimePick);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(email);
            groupBox1.Controls.Add(occupation);
            groupBox1.Controls.Add(lname);
            groupBox1.Controls.Add(fname);
            groupBox1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox1.Location = new Point(220, 40);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(846, 645);
            groupBox1.TabIndex = 18;
            groupBox1.TabStop = false;
            groupBox1.Text = "Personal Information";
            // 
            // sxCombo
            // 
            sxCombo.FormattingEnabled = true;
            sxCombo.Items.AddRange(new object[] { "Male", "Female", "other" });
            sxCombo.Location = new Point(323, 271);
            sxCombo.Name = "sxCombo";
            sxCombo.Size = new Size(400, 53);
            sxCombo.TabIndex = 11;
            // 
            // dateTimePick
            // 
            dateTimePick.Location = new Point(323, 358);
            dateTimePick.Name = "dateTimePick";
            dateTimePick.Size = new Size(400, 50);
            dateTimePick.TabIndex = 10;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(84, 538);
            label6.Name = "label6";
            label6.Size = new Size(195, 45);
            label6.TabIndex = 9;
            label6.Text = "Occupation:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(173, 450);
            label5.Name = "label5";
            label5.Size = new Size(106, 45);
            label5.TabIndex = 8;
            label5.Text = "Email:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(102, 358);
            label4.Name = "label4";
            label4.Size = new Size(177, 45);
            label4.TabIndex = 7;
            label4.Text = "Birth Date:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(207, 274);
            label3.Name = "label3";
            label3.Size = new Size(78, 45);
            label3.TabIndex = 6;
            label3.Text = "Sex:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(102, 187);
            label2.Name = "label2";
            label2.Size = new Size(183, 45);
            label2.TabIndex = 5;
            label2.Text = "Last Name:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(87, 92);
            label1.Name = "label1";
            label1.Size = new Size(198, 45);
            label1.TabIndex = 4;
            label1.Text = "Frirst Name:";
            // 
            // email
            // 
            email.Location = new Point(323, 450);
            email.Name = "email";
            email.Size = new Size(400, 50);
            email.TabIndex = 3;
            // 
            // occupation
            // 
            occupation.Location = new Point(323, 538);
            occupation.Name = "occupation";
            occupation.Size = new Size(400, 50);
            occupation.TabIndex = 2;
            // 
            // lname
            // 
            lname.Location = new Point(323, 187);
            lname.Name = "lname";
            lname.Size = new Size(400, 50);
            lname.TabIndex = 1;
            // 
            // fname
            // 
            fname.Location = new Point(323, 92);
            fname.Name = "fname";
            fname.Size = new Size(400, 50);
            fname.TabIndex = 0;
            // 
            // updateuser
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1329, 791);
            Controls.Add(submit);
            Controls.Add(groupBox1);
            Name = "updateuser";
            Text = "updateuser";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button submit;
        private GroupBox groupBox1;
        private ComboBox sxCombo;
        private DateTimePicker dateTimePick;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox email;
        private TextBox occupation;
        private TextBox lname;
        private TextBox fname;
    }
}