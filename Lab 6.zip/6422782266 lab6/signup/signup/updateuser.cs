﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace signup
{
    public partial class updateuser : Form
    {
        public int V { get; set; }
        public updateuser(int v)
        {
            InitializeComponent();
            V = v;
        }

        private void btn_submit_Click(object sender, EventArgs e)
        {
            string dateValue = dateTimePick.Value.ToString("yyyy-MM-dd");

            info a1 = new info()
            {
                ID = V,
                FName = fname.Text,
                LName = lname.Text,
                Sex = sxCombo.Text,
                Bdate = dateValue,
                Email = email.Text,
                Occup = occupation.Text,
            };
            infoDAO infor = new infoDAO();
            int result = infor.updateOneRecord(a1);
            this.Hide();
            userpage newuserpage = new userpage(infor.getAll(a1.ID));
            newuserpage.ShowDialog();
        }
    }
}

