﻿using MySql.Data.MySqlClient;
using Org.BouncyCastle.Utilities.Encoders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Xml.Linq;
using signup;

namespace signup
{
    internal class infoDAO
    {
        string connectionString = "datasource=localhost;port=3306;username=root;password=root;database=test;";

        public int addOneRecord(info a1)
        {
            int c;
            MySqlConnection connect = new MySqlConnection(connectionString);
            connect.Open();
            MySqlCommand cmd = new MySqlCommand("INSERT INTO `signup`(`First_Name`, `Last_Name`, `Sex`, `BirthDate`, `Email`,`Occupation`) VALUES (@fname, @lname, @sex, @birthdate, @email, @occupation)", connect);
            cmd.Parameters.AddWithValue("@fname", a1.FName);
            cmd.Parameters.AddWithValue("@lname", a1.LName);
            cmd.Parameters.AddWithValue("@sex", a1.Sex);
            cmd.Parameters.AddWithValue("@birthdate", a1.Bdate);
            cmd.Parameters.AddWithValue("@email", a1.Email);
            cmd.Parameters.AddWithValue("@Occupation", a1.Occup);
            int newRows = cmd.ExecuteNonQuery();
            info return_insert = new info();
            MySqlCommand cmd1 = new MySqlCommand("SELECT * FROM signup Order by ID desc Limit 1", connect);
            using (MySqlDataReader reader = cmd1.ExecuteReader())
            {
                while (reader.Read())
                {
                    return_insert = new info
                    {
                        ID = reader.GetInt32(0),
                        FName = reader.GetString(1),
                        LName = reader.GetString(2),
                        Sex = reader.GetString(3),
                        Bdate = reader.GetString(4),
                        Email = reader.GetString(5),
                        Occup = reader.GetString(6)
                    };

                }
                c = return_insert.ID;
            }
            connect.Close();
            return c;
        }

        public int addOneLoginRecord(login a1)
        {
            MySqlConnection connect = new MySqlConnection(connectionString);
            connect.Open();
            MySqlCommand cmd = new MySqlCommand("INSERT INTO login(Signup_ID, Username, Password) VALUES (@Signup_ID, @Username, @Password)", connect);
            cmd.Parameters.AddWithValue("@Signup_ID", a1.Signup_ID);
            cmd.Parameters.AddWithValue("@Username", a1.Username);
            cmd.Parameters.AddWithValue("@Password", a1.Password);
            int newRows = cmd.ExecuteNonQuery();
            connect.Close();
            return newRows;
        }

        internal int updateOneRecord(info a1)
        {
            MySqlConnection connect = new MySqlConnection(connectionString);
            connect.Open();
            MySqlCommand cmd = new MySqlCommand("UPDATE signup SET First_Name= @fname, Last_Name = @lname, Sex = @sex, BirthDate = @birthdate, Email = @email, Occupation = @Occupation WHERE ID = @ID", connect);
            cmd.Parameters.AddWithValue("@ID", a1.ID);
            cmd.Parameters.AddWithValue("@fname", a1.FName);
            cmd.Parameters.AddWithValue("@lname", a1.LName);
            cmd.Parameters.AddWithValue("@sex", a1.Sex);
            cmd.Parameters.AddWithValue("@birthdate", a1.Bdate);
            cmd.Parameters.AddWithValue("@email", a1.Email);
            cmd.Parameters.AddWithValue("@Occupation", a1.Occup);
            int newRows = cmd.ExecuteNonQuery();
            connect.Close();
            return newRows;
        }

        internal int deleteOneRecord(int id_row)
        {
            MySqlConnection connect = new
            MySqlConnection(connectionString);
            connect.Open();
            MySqlCommand cmd = new MySqlCommand("DELETE FROM `signup` WHERE `signup`.`ID` = @ID",
            connect);
            cmd.Parameters.AddWithValue("@ID", id_row);
            int newRows = cmd.ExecuteNonQuery();
            connect.Close();
            return newRows;
        }

        public List<info> getAll(int a)
        {
            List<info> returnall = new List<info>();
            MySqlConnection connect = new MySqlConnection(connectionString);
            connect.Open();
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM signup WHERE ID = @a", connect);
            cmd.Parameters.AddWithValue("@a", a);
            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    info ret = new info
                    {
                        ID = reader.GetInt32(0),
                        FName = reader.GetString(1),
                        LName = reader.GetString(2),
                        Sex = reader.GetString(3),
                        Bdate = reader.GetString(4),
                        Email = reader.GetString(5),
                        Occup = reader.GetString(6)
                    };
                    returnall.Add(ret);
                }
            }
            connect.Close();
            return returnall;
        }

        public List<login> GetLogin(string a)
        {
            List<login> returnall = new List<login>();
            MySqlConnection connect = new MySqlConnection(connectionString);
            connect.Open();
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM login WHERE Username = @a", connect);
            cmd.Parameters.AddWithValue("@a", a);
            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    login ret = new login
                    {
                        ID = reader.GetInt32(0),
                        Signup_ID = reader.GetInt32(1),
                        Username = reader.GetString(2),
                        Password = reader.GetString(3),
                    };
                    returnall.Add(ret);
                }
            }
            connect.Close();
            return returnall;
        }
    }
}
