﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace signup
{
    public partial class userpage : Form
    {
        public userpage(object v)
        {
            InitializeComponent();
            V = v;
        }
        public object V { get; set; }
        public int id_row { get; set; }

        BindingSource infobindingSource = new BindingSource();

        private void userpage_Load(object sender, EventArgs e)
        {
            infobindingSource.DataSource = V;
            dataGridView.DataSource = infobindingSource;
        }

        private void dataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridView dataGridView = (DataGridView)sender;
            id_row = Int32.Parse(dataGridView.Rows[0].Cells[0].Value.ToString());
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            infoDAO infor = new infoDAO();
            this.Hide();
            MessageBox.Show("a = " + id_row);
            updateuser newupdatepage = new updateuser(id_row);
            newupdatepage.ShowDialog();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            infoDAO infor = new infoDAO();
            int result = infor.deleteOneRecord(id_row);
            this.Hide();
        }
    }
}
