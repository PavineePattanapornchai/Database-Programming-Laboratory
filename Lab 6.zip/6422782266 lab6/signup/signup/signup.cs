﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace signup
{
    public partial class signup : Form
    {
        
        public signup()
        {
            InitializeComponent();
        }


        private void btn_submit_Click(object sender, EventArgs e)
        {
            string dateValue = dateTimePick.Value.ToString("yyyy-MM-dd");
            infoDAO infor = new infoDAO();

            if (!string.IsNullOrEmpty(this.userlog.Text) && !string.IsNullOrEmpty(this.passlog.Text))
            {
                try
                {
                    List<login> loginInfo = infor.GetLogin(this.userlog.Text);
                    if (this.userlog.Text == loginInfo[0].Username && this.passlog.Text == loginInfo[0].Password)
                    {
                        int loginID = loginInfo[0].Signup_ID;
                        MessageBox.Show("Login success");
                        userpage newuserpage1 = new userpage(infor.getAll(loginID));
                        newuserpage1.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Login failed");
                    }
                }
                catch
                {
                    MessageBox.Show("Login failed");
                }
            }
            else if ((!(string.IsNullOrEmpty(this.usersignup.Text) || string.IsNullOrEmpty(this.passsignup.Text) || string.IsNullOrEmpty(this.cfpasssignup.Text))) && string.IsNullOrEmpty(this.userlog.Text) && string.IsNullOrEmpty(this.passlog.Text))
            {
                if (!(string.IsNullOrEmpty(this.fname.Text) || string.IsNullOrEmpty(this.lname.Text) || string.IsNullOrEmpty(this.sxCombo.Text) || string.IsNullOrEmpty(this.email.Text) || string.IsNullOrEmpty(this.occupation.Text)))
                {
                    info a1 = new info()
                    {
                        FName = fname.Text,
                        LName = lname.Text,
                        Sex = sxCombo.Text,
                        Bdate = dateValue,
                        Email = email.Text,
                        Occup = occupation.Text
                    };
                    if (this.passsignup.Text == this.cfpasssignup.Text)
                    {
                        int a = infor.addOneRecord(a1);

                        login a2 = new login()
                        {
                            Signup_ID = a,
                            Username = this.usersignup.Text,
                            Password = this.passsignup.Text
                        };
                        int b = infor.addOneLoginRecord(a2);

                        MessageBox.Show("row added to information collector.");
                        userpage newuserpage2 = new userpage(infor.getAll(a));
                        newuserpage2.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Your passwords do not match");
                    }
                }
                else
                {
                    MessageBox.Show("Please fill all the fields in personal information");
                }
            }
            else
            {
                MessageBox.Show("Please fill all the fields in either login or signup section");
            }
        }
    }
}
