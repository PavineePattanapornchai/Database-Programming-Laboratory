﻿namespace Assignment2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            css326 = new Label();
            groupBox1 = new GroupBox();
            userg2 = new Button();
            usera = new Button();
            userg1 = new Button();
            userp = new Button();
            groupBox2 = new GroupBox();
            pre = new ComboBox();
            textemail = new TextBox();
            txtlastname = new TextBox();
            txtfirstname = new TextBox();
            labelemail = new Label();
            lablelastname = new Label();
            labelname = new Label();
            labeltitle = new Label();
            groupBox3 = new GroupBox();
            radstudent = new RadioButton();
            radta = new RadioButton();
            radinstructor = new RadioButton();
            busubmit = new Button();
            label4 = new Label();
            textconfirmpass = new TextBox();
            textpass = new TextBox();
            textusername = new TextBox();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // css326
            // 
            css326.BackColor = SystemColors.ActiveCaption;
            css326.Dock = DockStyle.Top;
            css326.FlatStyle = FlatStyle.Flat;
            css326.Font = new Font("Arial Black", 19.875F, FontStyle.Bold, GraphicsUnit.Point);
            css326.ForeColor = Color.Black;
            css326.Location = new Point(0, 0);
            css326.Name = "css326";
            css326.Size = new Size(1250, 74);
            css326.TabIndex = 0;
            css326.Text = "CSS326 Laboratory System";
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.ButtonFace;
            groupBox1.Controls.Add(userg2);
            groupBox1.Controls.Add(usera);
            groupBox1.Controls.Add(userg1);
            groupBox1.Controls.Add(userp);
            groupBox1.Font = new Font("Arial Narrow", 13.875F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox1.Location = new Point(12, 77);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(320, 811);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "Form Navigation";
            // 
            // userg2
            // 
            userg2.Location = new Point(24, 260);
            userg2.Name = "userg2";
            userg2.Size = new Size(270, 77);
            userg2.TabIndex = 3;
            userg2.Text = "User Group";
            userg2.UseVisualStyleBackColor = true;
            // 
            // usera
            // 
            usera.Location = new Point(21, 130);
            usera.Name = "usera";
            usera.Size = new Size(273, 46);
            usera.TabIndex = 1;
            usera.Text = "User Add-in";
            usera.UseVisualStyleBackColor = true;
            // 
            // userg1
            // 
            userg1.Location = new Point(24, 190);
            userg1.Name = "userg1";
            userg1.Size = new Size(270, 46);
            userg1.TabIndex = 2;
            userg1.Text = "User Group";
            userg1.UseVisualStyleBackColor = true;
            // 
            // userp
            // 
            userp.BackColor = SystemColors.ButtonHighlight;
            userp.Location = new Point(21, 68);
            userp.Name = "userp";
            userp.Size = new Size(273, 46);
            userp.TabIndex = 0;
            userp.Text = "User Profie";
            userp.UseVisualStyleBackColor = false;
            userp.Click += userp_Click;
            // 
            // groupBox2
            // 
            groupBox2.BackColor = SystemColors.ButtonFace;
            groupBox2.Controls.Add(pre);
            groupBox2.Controls.Add(textemail);
            groupBox2.Controls.Add(txtlastname);
            groupBox2.Controls.Add(txtfirstname);
            groupBox2.Controls.Add(labelemail);
            groupBox2.Controls.Add(lablelastname);
            groupBox2.Controls.Add(labelname);
            groupBox2.Controls.Add(labeltitle);
            groupBox2.Font = new Font("Arial Narrow", 13.875F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox2.Location = new Point(348, 77);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(890, 338);
            groupBox2.TabIndex = 2;
            groupBox2.TabStop = false;
            groupBox2.Text = "User Information";
            // 
            // pre
            // 
            pre.FormattingEnabled = true;
            pre.Items.AddRange(new object[] { "Ms", "Mr", "Mrs", "Miss" });
            pre.Location = new Point(366, 49);
            pre.Name = "pre";
            pre.Size = new Size(242, 51);
            pre.TabIndex = 8;
            // 
            // textemail
            // 
            textemail.Location = new Point(366, 258);
            textemail.Name = "textemail";
            textemail.Size = new Size(394, 50);
            textemail.TabIndex = 7;
            // 
            // txtlastname
            // 
            txtlastname.Location = new Point(366, 186);
            txtlastname.Name = "txtlastname";
            txtlastname.Size = new Size(394, 50);
            txtlastname.TabIndex = 6;
            // 
            // txtfirstname
            // 
            txtfirstname.Location = new Point(366, 119);
            txtfirstname.Name = "txtfirstname";
            txtfirstname.Size = new Size(394, 50);
            txtfirstname.TabIndex = 5;
            txtfirstname.TextChanged += txtfirstname_TextChanged;
            // 
            // labelemail
            // 
            labelemail.AutoSize = true;
            labelemail.Location = new Point(224, 261);
            labelemail.Name = "labelemail";
            labelemail.Size = new Size(99, 43);
            labelemail.TabIndex = 3;
            labelemail.Text = "Email";
            // 
            // lablelastname
            // 
            lablelastname.AutoSize = true;
            lablelastname.Location = new Point(153, 193);
            lablelastname.Name = "lablelastname";
            lablelastname.Size = new Size(173, 43);
            lablelastname.TabIndex = 2;
            lablelastname.Text = "Last Name";
            // 
            // labelname
            // 
            labelname.AutoSize = true;
            labelname.Location = new Point(150, 119);
            labelname.Name = "labelname";
            labelname.Size = new Size(176, 43);
            labelname.TabIndex = 1;
            labelname.Text = "First Name";
            // 
            // labeltitle
            // 
            labeltitle.AutoSize = true;
            labeltitle.Location = new Point(242, 55);
            labeltitle.Name = "labeltitle";
            labeltitle.Size = new Size(81, 43);
            labeltitle.TabIndex = 0;
            labeltitle.Text = "Title";
            // 
            // groupBox3
            // 
            groupBox3.BackColor = SystemColors.Control;
            groupBox3.Controls.Add(radstudent);
            groupBox3.Controls.Add(radta);
            groupBox3.Controls.Add(radinstructor);
            groupBox3.Controls.Add(busubmit);
            groupBox3.Controls.Add(label4);
            groupBox3.Controls.Add(textconfirmpass);
            groupBox3.Controls.Add(textpass);
            groupBox3.Controls.Add(textusername);
            groupBox3.Controls.Add(label3);
            groupBox3.Controls.Add(label2);
            groupBox3.Controls.Add(label1);
            groupBox3.Font = new Font("Arial Narrow", 13.875F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox3.Location = new Point(348, 421);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(890, 467);
            groupBox3.TabIndex = 3;
            groupBox3.TabStop = false;
            groupBox3.Text = "Account Information";
            // 
            // radstudent
            // 
            radstudent.AutoSize = true;
            radstudent.Location = new Point(698, 307);
            radstudent.Name = "radstudent";
            radstudent.Size = new Size(164, 47);
            radstudent.TabIndex = 10;
            radstudent.TabStop = true;
            radstudent.Text = "Student";
            radstudent.UseVisualStyleBackColor = true;
            // 
            // radta
            // 
            radta.AutoSize = true;
            radta.Location = new Point(576, 309);
            radta.Name = "radta";
            radta.Size = new Size(91, 47);
            radta.TabIndex = 9;
            radta.TabStop = true;
            radta.Text = "TA";
            radta.UseVisualStyleBackColor = true;
            // 
            // radinstructor
            // 
            radinstructor.AutoSize = true;
            radinstructor.Location = new Point(366, 307);
            radinstructor.Name = "radinstructor";
            radinstructor.Size = new Size(193, 47);
            radinstructor.TabIndex = 8;
            radinstructor.TabStop = true;
            radinstructor.Text = "Instructor";
            radinstructor.UseVisualStyleBackColor = true;
            // 
            // busubmit
            // 
            busubmit.Location = new Point(324, 388);
            busubmit.Name = "busubmit";
            busubmit.Size = new Size(150, 46);
            busubmit.TabIndex = 7;
            busubmit.Text = "Submit";
            busubmit.UseVisualStyleBackColor = true;
            busubmit.Click += busubmit_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(135, 309);
            label4.Name = "label4";
            label4.Size = new Size(188, 43);
            label4.TabIndex = 6;
            label4.Text = "User Group";
            // 
            // textconfirmpass
            // 
            textconfirmpass.Location = new Point(366, 220);
            textconfirmpass.Name = "textconfirmpass";
            textconfirmpass.Size = new Size(394, 50);
            textconfirmpass.TabIndex = 5;
            // 
            // textpass
            // 
            textpass.Location = new Point(366, 139);
            textpass.Name = "textpass";
            textpass.Size = new Size(394, 50);
            textpass.TabIndex = 4;
            // 
            // textusername
            // 
            textusername.Location = new Point(366, 66);
            textusername.Name = "textusername";
            textusername.Size = new Size(394, 50);
            textusername.TabIndex = 3;
            textusername.TextChanged += textusername_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(37, 220);
            label3.Name = "label3";
            label3.Size = new Size(289, 43);
            label3.TabIndex = 2;
            label3.Text = "Confirm Password";
            label3.Click += label3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(162, 146);
            label2.Name = "label2";
            label2.Size = new Size(164, 43);
            label2.TabIndex = 1;
            label2.Text = "Password";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(159, 69);
            label1.Name = "label1";
            label1.Size = new Size(167, 43);
            label1.TabIndex = 0;
            label1.Text = "Username";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLightLight;
            ClientSize = new Size(1250, 894);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(css326);
            Name = "Form1";
            Text = "User Add-in";
            groupBox1.ResumeLayout(false);
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label css326;
        private GroupBox groupBox1;
        private Button userp;
        private Button userg2;
        private Button usera;
        private Button userg1;
        private GroupBox groupBox2;
        private Label labelname;
        private Label labeltitle;
        private Label labelemail;
        private Label lablelastname;
        private TextBox textemail;
        private TextBox txtlastname;
        private TextBox txtfirstname;
        private GroupBox groupBox3;
        private Label label3;
        private Label label2;
        private Label label1;
        private RadioButton radstudent;
        private RadioButton radta;
        private RadioButton radinstructor;
        private Button busubmit;
        private Label label4;
        private TextBox textconfirmpass;
        private TextBox textpass;
        private TextBox textusername;
        private ComboBox pre;
    }
}