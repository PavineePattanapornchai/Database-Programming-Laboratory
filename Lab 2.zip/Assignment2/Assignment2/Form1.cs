namespace Assignment2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textusername_TextChanged(object sender, EventArgs e)
        {

        }

        private void busubmit_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(pre.Text,txtfirstname.Text,txtlastname.Text);
            this.Hide();
            form2.ShowDialog();
            this.Show();
        }

        private void userp_Click(object sender, EventArgs e)
        {

        }

        private void txtfirstname_TextChanged(object sender, EventArgs e)
        {

        }
    }
}