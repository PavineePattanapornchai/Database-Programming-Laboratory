﻿namespace Assignment2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            css3262 = new Label();
            userg2 = new Button();
            usera = new Button();
            userg1 = new Button();
            userp = new Button();
            groupBox1 = new GroupBox();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            pictureBox2 = new PictureBox();
            groupBox2 = new GroupBox();
            label2 = new Label();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // css3262
            // 
            css3262.BackColor = SystemColors.ActiveCaption;
            css3262.Font = new Font("Arial Black", 19.875F, FontStyle.Bold, GraphicsUnit.Point);
            css3262.Location = new Point(-3, -3);
            css3262.Name = "css3262";
            css3262.Size = new Size(1250, 74);
            css3262.TabIndex = 0;
            css3262.Text = "CSS326 Laboratory System";
            // 
            // userg2
            // 
            userg2.Font = new Font("Arial Narrow", 13.875F, FontStyle.Bold, GraphicsUnit.Point);
            userg2.Location = new Point(29, 269);
            userg2.Name = "userg2";
            userg2.Size = new Size(270, 77);
            userg2.TabIndex = 7;
            userg2.Text = "User Group";
            userg2.UseVisualStyleBackColor = true;
            // 
            // usera
            // 
            usera.Font = new Font("Arial Narrow", 13.875F, FontStyle.Bold, GraphicsUnit.Point);
            usera.Location = new Point(26, 139);
            usera.Name = "usera";
            usera.Size = new Size(273, 46);
            usera.TabIndex = 5;
            usera.Text = "User Add-in";
            usera.UseVisualStyleBackColor = true;
            usera.Click += usera_Click;
            // 
            // userg1
            // 
            userg1.Font = new Font("Arial Narrow", 13.875F, FontStyle.Bold, GraphicsUnit.Point);
            userg1.Location = new Point(29, 199);
            userg1.Name = "userg1";
            userg1.Size = new Size(270, 46);
            userg1.TabIndex = 6;
            userg1.Text = "User Group";
            userg1.UseVisualStyleBackColor = true;
            // 
            // userp
            // 
            userp.BackColor = SystemColors.ButtonHighlight;
            userp.Font = new Font("Arial Narrow", 13.875F, FontStyle.Bold, GraphicsUnit.Point);
            userp.Location = new Point(26, 77);
            userp.Name = "userp";
            userp.Size = new Size(273, 46);
            userp.TabIndex = 4;
            userp.Text = "User Profie";
            userp.UseVisualStyleBackColor = false;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(userg2);
            groupBox1.Controls.Add(userp);
            groupBox1.Controls.Add(usera);
            groupBox1.Controls.Add(userg1);
            groupBox1.Font = new Font("Arial Narrow", 13.875F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox1.Location = new Point(12, 86);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(335, 811);
            groupBox1.TabIndex = 8;
            groupBox1.TabStop = false;
            groupBox1.Text = "Form Navigation";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = SystemColors.ActiveCaption;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(993, 661);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(199, 201);
            pictureBox1.TabIndex = 9;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 13.875F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(414, 162);
            label1.Name = "label1";
            label1.Size = new Size(106, 44);
            label1.TabIndex = 10;
            label1.Text = "hello";
            label1.Click += label1_Click_1;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(353, 86);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(885, 806);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 11;
            pictureBox2.TabStop = false;
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.Transparent;
            groupBox2.Controls.Add(label2);
            groupBox2.Font = new Font("Arial Narrow", 13.875F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox2.Location = new Point(414, 232);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(792, 200);
            groupBox2.TabIndex = 12;
            groupBox2.TabStop = false;
            groupBox2.Text = "Description";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(55, 63);
            label2.Name = "label2";
            label2.Size = new Size(650, 32);
            label2.TabIndex = 0;
            label2.Text = "We are glad to welcome you as one of the Students.";
            label2.Click += label2_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1250, 904);
            Controls.Add(groupBox2);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Controls.Add(groupBox1);
            Controls.Add(css3262);
            Controls.Add(pictureBox2);
            Name = "Form2";
            Text = "Form2";
            groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label css3262;
        private Button userg2;
        private Button usera;
        private Button userg1;
        private Button userp;
        private GroupBox groupBox1;
        private PictureBox pictureBox1;
        private Label label1;
        private PictureBox pictureBox2;
        private GroupBox groupBox2;
        private Label label2;
    }
}