<?php
session_start();

$errorMessage = ""; 
$showWelcomeMessage = false;
$showBackButton = false; 
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST["username"]) && isset($_POST["passwd"]) && isset($_POST["confirmpasswd"])) {
        $username = $_POST["username"];
        $pass = $_POST["passwd"];
        $pass1 = $_POST["confirmpasswd"];

        if ($username === "Admin" && $pass === "1234" && $pass1 === "1234") {
            $_SESSION["username"] = $username;
            $showWelcomeMessage = true;
        } else {
            $errorMessage = "You do not have access to this page!";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="default1.css"> 
    <style>
        body {
            background-image: url('back.jpg');
            background-size: cover;
            background-repeat: no-repeat;
        }
    </style>
</head>
<body>
    <?php
    if (!empty($errorMessage)) {
        echo "<h1>$errorMessage</h1>";
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            echo "<p id='countdown'>You will be redirected in 30 seconds</p>";
            echo "<p id='back-countdown' style='display: none'>Back in 0 seconds</p>";
            echo "<button id='backButton' style='display: none' onclick='history.go(-1);'>Back</button>";
            echo "<script>
                var countdown = 30;
                var countdownElement = document.getElementById('countdown');
                var backCountdownElement = document.getElementById('back-countdown');
                var backButton = document.getElementById('backButton');
                
                function updateCountdown() {
                    countdownElement.textContent = 'You will be redirected in ' + countdown + ' seconds';
                    backCountdownElement.textContent = 'Back in ' + countdown + ' seconds';
                    countdown--;
                    
                    if (countdown < 0) {
                        clearInterval(countdownInterval);
                        backButton.style.display = 'block'; // Show the Back button
                    }
                }
                
                var countdownInterval = setInterval(updateCountdown, 1000);
            </script>";
        }
        exit; 
    }
    ?>

    <?php if ($showWelcomeMessage) : ?>
    <h1 style="font-family: Arial; font-size: 200%; text-align: center;">
        Welcome <?php echo $_POST["title"], " ", $_POST["firstname"], " ", $_POST["lastname"]; ?>!!!
    </h1>
    <?php endif; ?>
    <img src="avatar.png" height="240" alt="Avatar Image">
    <h3 style="font-family: Arial; font-size: 170%;">This is your profile</h3>
    <p style="font-family: Arial;">
        Name: <?php echo $_POST["title"], " ", $_POST["firstname"], " ", $_POST["lastname"]; ?><br>
        User Group: <?php echo $_POST["usergroup"]; ?><br>
        Email address: <?php echo $_POST["email"]; ?><br>
        Gender: <?php echo $_POST["gender"]; ?><br>

        <?php
        date_default_timezone_set("Asia/Bangkok");
        echo "Login time (local): " . date("H:i:s") . " on " . date("Y-m-d");
        ?>
    </p>
    <p style="font-family: Arial; font-weight: bold; font-size: 150%;">Welcome to the CSS326 system</p>
    <p style="font-family: Arial;">
        Whether you are an experienced programmer or not, this website is intended for everyone who wishes to learn Database programming.
        There is no need to download anything - just click on the chapter you wish to begin from, and follow the instructions.
    </p>
    <ul>
        <li><a href="https://www.learn-php.org/en/Hello%2C_World%21" target="_blank">Hello World!</a></li>
        <li><a href="https://www.learn-php.org/en/Variables_and_Types" target="_blank">Variables</a></li>
        <li><a href="https://www.learn-php.org/en/For_loops" target="_blank">For Loops</a></li>
        <li><a href="https://www.learn-php.org/en/Functions" target="_blank">Functions</a></li>
        <li><a href="https://www.learn-php.org/en/While_loops" target="_blank">While loops</a></li>
    </ul>
    <p style="font-weight: bold; font-family: Arial; font-size: 120%; text-align: center;">Good Luck!</p>
    <?php if (isset($_SESSION["username"])) : ?>
        <button onclick='history.go(-1);'>Back</button>
    <?php endif; ?>
</body>
</html>
