<!DOCTYPE html>


<html>
<head>
<link rel="stylesheet" type="text/css" href="sticky.css">
</head>

<body>
	<form action="<?= $_SERVER["PHP_SELF"]?>" method="POST">
		<b>Title</b>: <input type="text" name="title" id="title" size="30" > <br><br>
		<b>Note</b>: <textarea name="note" cols="30" rows="5" ></textarea> <br>
		<input type="submit" value="Post!" name="submit" >
	</form>
	<hr>
	<!-- Put Display Content here -->
	<div class="post">
		<div class="title">
			<?php
			if (isset($_POST['submit'])) {
                $title = $_POST['title'];
                // Open a file named "sticky_note.txt" for writing
                $file = fopen("sticky_note.txt", "a");
                // Write the title in the text file
                fwrite($file, "Title: " . $title . "\n");
                // Close the text file
                fclose($file);
                echo $title;
            }
			?>
		</div>
		<div class="note">
			<?php
			if (isset($_POST['submit'])) {
                $note = $_POST['note'];
                // Open the same file for writing
                $file = fopen("sticky_note.txt", "a");
                // Write the note in the text file
                fwrite($file, "Note: " . $note . "\n");
                // Close the text filea
                fclose($file);
                echo $note;
            }
			?>
		</div>
		<div class="notefoot">
			<?php
			if (isset($_POST['submit'])) {
                // Open the file to count the total number of notes
                $file = fopen("sticky_note.txt", "r");
                $count = 0;
                while (!feof($file)) {
                    $line = fgets($file);
                    if (strpos($line, "Title:") === 0) {
                        $count++;
                    }
                }
                fclose($file);
                // Output the total number of notes
                echo $count . " notes have been made";
            }
			?>
		</div>
	</div>
</body>

</html>