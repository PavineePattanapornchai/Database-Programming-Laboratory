<?php require_once('connect.php'); ?> 
<!DOCTYPE html>
<html>
<head>
<title>CSS326 Sample</title>
<link rel="stylesheet" href="default.css">
</head>
<body>
<div id="wrapper"> 
	<?php include 'header.php'; ?>
	<div id="div_main">
		<div id="div_left">
				
		</div>
		<div id="div_content" class="usergroup">
			<!--%%%%% Main block %%%%-->
			<?php 
				if(isset($_POST['submit'])) {
					// groupcode, groupname, remark, url should be inserted to USERGROUP table
					$mysqli = new mysqli('localhost' ,'root' ,'root' ,'staff');

				if ($mysqli->connect_errno){
					echo $mysqli->connect_errno . ": " . $mysqli->connect_error;
				}

				$insert =  array($_POST['groupcode'],$_POST['groupname'],$_POST['remark'], $_POST['url']);
				$q = "INSERT INTO USERGROUP(USERGROUP_CODE, USERGROUP_NAME, USERGROUP_REMARK, USERGROUP_URL)";
        		$q = $q . " VALUES('$insert[0]', '$insert[1]', '$insert[2]', '$insert[3]')";
        		if (!$mysqli->query($q)){
            		echo"INSERT FAILED";
        		}

				}
			?>
			<h2>User Group</h2>			
			<table>
                <col width="10%">
                <col width="20%">
                <col width="30%">
                <col width="30%">
                <col width="5%">
                <col width="5%">

                <tr>
                    <th>Group Code</th> 
                    <th>Group Name</th>
                    <th>Remark</th>
                    <th>URL</th>
                    <th>Edit</th>
                    <th>Del</th>
                </tr>
				 <?php
				 	$q="select * from USERGROUP";
					$result=$mysqli->query($q);
					if(!$result){
						echo "Select failed. Error: ".$mysqli->error ;
						return false;
					}
				 while($row=$result->fetch_array()){ ?>
                 <tr>
                    <td><?php echo $row['USERGROUP_CODE']?></td> 
                    <td><?php echo $row['USERGROUP_NAME']?></td>
                    <td><?php echo $row['USERGROUP_REMARK']?></td>
                    <td><?php echo $row['USERGROUP_URL']?></td>
                    <td><a href='edit_group.php?groupid=<?php echo $row['USERGROUP_ID'];?>'><img src="images/Modify.png" width="24" height="24"></td>
                    <td><a href='delinfo.php?id=<?php echo $row['USERGROUP_ID'];?>'> <img src="images/Delete.png" width="24" height="24"></a></td>
                </tr>                               
				<?php } ?>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
			<td>
			<?php 
			// count the no. of entries
			
			$count = "SELECT COUNT(USERGROUP_CODE) FROM USERGROUP";
			$num = $mysqli->query($count);
			if ($result) {
				$row = $num->fetch_row();
				$rowCount = $row[0]; // The count value is at index 0
				echo "Total " . $rowCount . " records";
			} else {
				echo "Error: " . $mysqli->error;
			}
			
			?>
			</td>
            </table>	
				
		</div> <!-- end div_content -->
		
	</div> <!-- end div_main -->
	
	<div id="div_footer">  
		
	</div>

</div>
</body>
</html>


